INSERT INTO suppliers (name, phone_number) VALUES
('Supplier1', '123-456-7890'),
('Supplier2', '987-654-3210'),
('Supplier3', '423-646-7900'),
('Supplier4', '657-375-4812');

-- Вставка данных в таблицу clients
INSERT INTO clients (full_name, email, phone_number) VALUES
('John Doe', 'john.doe@example.com', '513-546-888'),
('Jane Smith', 'jane.smith@example.com', '653-183-448');

-- Вставка данных в таблицу available_details
INSERT INTO available_details (name, supplier_id, price)
VALUES
('Display', 1, 50),
('Keyboard', 2, 25),
('Motherboard', 3, 40),
('Battery', 4, 15),
('Display', 1, 40),
('Processor', 2, 40),
('Motherboard', 3, 40),
('RAM', 4, 20);

-- Вставка данных в таблицу orders
INSERT INTO orders (client_id, order_name, status, price)
VALUES
(1, 'repair display', 'READY', 50),
(2, 'replace battery', 'IN PROGRESS', 15);

-- Вставка данных в таблицу ordered_details
INSERT INTO ordered_details (available_detail_id, quantity, status, order_date, delivery_date)
VALUES
(1, 10, 'IN PROGRESS', '2024-12-01', '2024-12-03'),
(4, 20, 'DELIVERED', '2024-12-02', '2024-12-04');