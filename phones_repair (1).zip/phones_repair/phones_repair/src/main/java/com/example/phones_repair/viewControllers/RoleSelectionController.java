package com.example.phones_repair.viewControllers;

import com.example.phones_repair.viewControllers.client.ClientRegistrationController;
import com.example.phones_repair.viewControllers.master.MasterViewController;
import javafx.fxml.FXML;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import net.rgielen.fxweaver.core.FxWeaver;
import net.rgielen.fxweaver.core.FxmlView;
import org.springframework.stereotype.Component;

@Component
@FxmlView("/view/RoleSelectionView.fxml")
public class RoleSelectionController {

    private final FxWeaver fxWeaver;

    @FXML
    private Button clientButton;

    @FXML
    private Button masterButton;

    public RoleSelectionController(FxWeaver fxWeaver) {
        this.fxWeaver = fxWeaver;
    }

    @FXML
    public void initialize() {
        clientButton.setOnAction(e -> openClientRegistrationWindow());
        masterButton.setOnAction(e -> openMasterWindow());
    }

    private void openClientRegistrationWindow() {
        Parent clientView = fxWeaver.loadView(ClientRegistrationController.class);
        Stage stage = (Stage) clientButton.getScene().getWindow();
        stage.setTitle("Client Registration");
        stage.setScene(new Scene(clientView));
        stage.show();
    }

    private void openMasterWindow() {
        Parent masterView = fxWeaver.loadView(MasterViewController.class);
        Stage stage = (Stage) masterButton.getScene().getWindow();
        stage.setTitle("Master");
        stage.setScene(new Scene(masterView));
        stage.show();
    }

}
