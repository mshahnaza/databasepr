package com.example.phones_repair.viewControllers.master;

import javafx.fxml.FXML;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import net.rgielen.fxweaver.core.FxWeaver;
import net.rgielen.fxweaver.core.FxmlView;
import org.springframework.stereotype.Component;

@Component
@FxmlView("/view/MasterWindow.fxml")
public class MasterViewController {

    private final FxWeaver fxWeaver;
    
    @FXML
    private Button viewOrdersButton;
    
    @FXML
    private Button executeOrderButton;
    
    public MasterViewController(FxWeaver fxWeaver) {
        this.fxWeaver = fxWeaver;
    }

    @FXML
    public void initialize() {
        viewOrdersButton.setOnAction(e -> openOrdersWindow());
        executeOrderButton.setOnAction(e -> openOrderExecutionWindow());
    }

    private void openOrderExecutionWindow() {
        Parent executionView = fxWeaver.loadView(OrderExecutionController.class);
        Stage stage = (Stage) executeOrderButton.getScene().getWindow();
        stage.setTitle("Orders execution");
        stage.setScene(new Scene(executionView));
        stage.show();
    }

    private void openOrdersWindow() {
        Parent ordersView = fxWeaver.loadView(OrderListController.class);
        Stage stage = (Stage) viewOrdersButton.getScene().getWindow();
        stage.setTitle("Orders");
        stage.setScene(new Scene(ordersView));
        stage.show();
    }


}
