package com.example.phones_repair.viewControllers.client;

import net.rgielen.fxweaver.core.FxmlView;
import org.springframework.stereotype.Component;

@Component
@FxmlView("/view/MakeOrderView.fxml")
public class MakeOrderController {
    public MakeOrderController() {}
}
