package com.example.phones_repair.dto.details;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DetailSendRequest {
    private Long order_id;
}
