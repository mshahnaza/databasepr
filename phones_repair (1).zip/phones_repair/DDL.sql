DROP TABLE IF EXISTS ordered_details;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS available_details;
DROP TABLE IF EXISTS suppliers;
DROP TABLE IF EXISTS clients;

CREATE TABLE suppliers (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR(255),
    phone_number VARCHAR(20)
);

CREATE TABLE clients (
    id BIGSERIAL PRIMARY KEY,
    full_name VARCHAR(255),
    email VARCHAR(255) UNIQUE,
    phone_number VARCHAR(20)
);

CREATE TABLE available_details (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    supplier_id BIGINT,
    price INT NOT NULL,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(id) 
        ON DELETE SET NULL
);

CREATE TABLE orders (
    id BIGSERIAL PRIMARY KEY,
    client_id BIGINT,
    order_name VARCHAR(255),
    status VARCHAR(50),
    price INT,
    FOREIGN KEY (client_id) REFERENCES clients(id)
        ON DELETE SET NULL
);

CREATE TABLE ordered_details (
    id SERIAL PRIMARY KEY,
    available_detail_id BIGINT NOT NULL,
    quantity INT NOT NULL,
    status VARCHAR(255) NOT NULL,
    order_date DATE NOT NULL,
    delivery_date DATE,
    FOREIGN KEY (available_detail_id) REFERENCES available_details(id)
);