package com.example.phones_repair.dto.user;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserRegisterRequest {
    private String email;

    private String fullName;

    private String password;

    private String phoneNumber;
}
