package com.example.phones_repair.service;

import com.example.phones_repair.dto.user.AuthLoginRequest;
import com.example.phones_repair.dto.user.AuthLoginResponse;
import com.example.phones_repair.dto.user.UserRegisterRequest;

public interface AuthService {
    void register(UserRegisterRequest userRegisterRequest);

    AuthLoginResponse login(AuthLoginRequest authLoginRequest);
}
