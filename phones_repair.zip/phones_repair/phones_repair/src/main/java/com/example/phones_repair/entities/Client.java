package com.example.phones_repair.entities;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "clients")
public class Client {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne//(mappedBy = "client")
    @JoinColumn(name = "user_id", referencedColumnName = "id")
    private User user;

    private String fullName;

    @Column(unique = true)
    private String email;

    private String phoneNumber;

}
