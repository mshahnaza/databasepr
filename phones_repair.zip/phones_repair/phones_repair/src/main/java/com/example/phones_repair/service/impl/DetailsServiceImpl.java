package com.example.phones_repair.service.impl;

import com.example.phones_repair.dto.details.DetailOrderRequest;
import com.example.phones_repair.dto.details.DetailOrderResponse;
import com.example.phones_repair.dto.details.DetailSendRequest;
import com.example.phones_repair.entities.Details;
import com.example.phones_repair.exception.NotFoundException;
import com.example.phones_repair.mapper.DetailsMapper;
import com.example.phones_repair.repositories.DetailsRepository;
import com.example.phones_repair.service.DetailsService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
@AllArgsConstructor
public class DetailsServiceImpl implements DetailsService {
    @Autowired
    private DetailsRepository detailsRepository;

    @Autowired
    private DetailsMapper detailsMapper;

    @Override
    public void orderDetail(DetailOrderRequest orderRequest) {
        Details details = new Details();
        details.setDetailName(orderRequest.getDetailName());
        details.setQuantity(orderRequest.getQuantity());
        details.setStatus("IN PROGRESS");
        details.setOrderDate(LocalDate.now());
        details.setDeliveryDate(details.getOrderDate().plusDays(2));
        detailsRepository.save(details);
    }

    @Override
    public void deleteOrder(Long id) {
        if (detailsRepository.findById(id).isEmpty())
            throw new NotFoundException("The detail with id: "+id+" is not found!", HttpStatus.BAD_REQUEST);
        detailsRepository.deleteById(id);
    }

    @Override
    public List<DetailOrderResponse> showOrders() {
        return detailsMapper.toDtoS(detailsRepository.findAll());
    }

    @Override
    public void sendDetail(DetailSendRequest orderRequest) {
        Details details = detailsRepository.findById(orderRequest.getOrder_id())
                .orElseThrow(() -> new NotFoundException("The order with id: "+ orderRequest.getOrder_id() +" is not found!", HttpStatus.BAD_REQUEST));
        details.setStatus("DELIVERED");
        detailsRepository.save(details);
    }

    @Override
    public List<DetailOrderResponse> showInProgressOrders() {
        List<Details> inProgressOrders = detailsRepository.findByStatus("IN PROGRESS");

        return detailsMapper.toDtoS(inProgressOrders);
    }

    @Override
    public List<DetailOrderResponse> showFinishedOrders() {
        List<Details> inProgressOrders = detailsRepository.findByStatus("DELIVERED");

        return detailsMapper.toDtoS(inProgressOrders);
    }
}
