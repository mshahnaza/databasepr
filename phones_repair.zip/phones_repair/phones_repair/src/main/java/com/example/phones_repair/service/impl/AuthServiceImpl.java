package com.example.phones_repair.service.impl;

import com.example.phones_repair.dto.user.AuthLoginRequest;
import com.example.phones_repair.dto.user.AuthLoginResponse;
import com.example.phones_repair.dto.user.UserRegisterRequest;
import com.example.phones_repair.service.AuthService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class AuthServiceImpl implements AuthService {

    @Override
    public void register(UserRegisterRequest userRegisterRequest) {

    }

    @Override
    public AuthLoginResponse login(AuthLoginRequest authLoginRequest) {
        return null;
    }
}
