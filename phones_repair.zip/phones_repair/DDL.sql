CREATE TABLE users (
    id BIGSERIAL PRIMARY KEY,
    username VARCHAR(255),
    password VARCHAR(255),
    role VARCHAR(50)
);

CREATE TABLE suppliers (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR(255),
    phone_number VARCHAR(20)
);

CREATE TABLE orders (
    id BIGSERIAL PRIMARY KEY,
    client_id BIGINT NOT NULL,
    order_name VARCHAR(255),
    status VARCHAR(50),
    price INT,
    FOREIGN KEY (client_id) REFERENCES clients(id)
);

CREATE TABLE ordered_details (
    id BIGSERIAL PRIMARY KEY,
    detail_name VARCHAR(255) NOT NULL,
    quantity INT NOT NULL,
    status VARCHAR(50) NOT NULL,
    order_date DATE NOT NULL,
    delivery_date DATE
);

CREATE TABLE clients (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT,
    full_name VARCHAR(255),
    email VARCHAR(255) UNIQUE,
    phone_number VARCHAR(20),
    FOREIGN KEY (user_id) REFERENCES users(id)
);
