DELETE FROM orders;
DELETE FROM ordered_details;
DELETE FROM clients;
DELETE FROM suppliers;
DELETE FROM users;

INSERT INTO users (username, password, role) VALUES
('john_doe', 'password123', 'CLIENT'),
('admin_user', 'admin123', 'MASTER');

INSERT INTO suppliers (name, phone_number) VALUES
('Supplier1', '123-456-7890'),
('Supplier2', '987-654-3210');

INSERT INTO clients (user_id, full_name, email, phone_number) VALUES
(1, 'John Doe', 'john.doe@example.com', '513-546-888'),
(2, 'Jane Smith', 'jane.smith@example.com', '653-183-448');

INSERT INTO ordered_details (detail_name, quantity, status, order_date, delivery_date) VALUES
('display', 10, 'IN PROGRESS', '2024-12-01', '2024-12-03'),
('battery', 20, 'DELIVERED', '2024-12-02', '2024-12-04');

INSERT INTO orders (client_id, order_name, status, price) VALUES
(1, 'repair display', 'READY', 50),
(2, 'replace battery', 'IN PROGRESS', 15);
