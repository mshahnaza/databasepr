package com.example.phones_repair.enums;

public enum Role {
    MASTER,
    SUPPLIER,
    WORKER,
    CLIENT
}
