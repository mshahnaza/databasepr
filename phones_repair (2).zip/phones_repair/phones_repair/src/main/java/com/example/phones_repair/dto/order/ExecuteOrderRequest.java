package com.example.phones_repair.dto.order;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ExecuteOrderRequest {
    private Long order_id;
}
