package com.example.phones_repair.service;

import com.example.phones_repair.dto.user.ClientRegisterRequest;

public interface ClientService {

    void registerClient(ClientRegisterRequest registerRequest);
}
