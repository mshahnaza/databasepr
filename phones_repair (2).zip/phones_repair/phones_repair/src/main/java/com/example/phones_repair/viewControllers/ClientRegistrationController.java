package com.example.phones_repair.viewControllers;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import com.example.phones_repair.service.ClientService;
import net.rgielen.fxweaver.core.FxmlView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

@Component
@FxmlView("/view/ClientRegistrationWindow.fxml")
public class ClientRegistrationController {

    @FXML
    private TextField emailField;

    @FXML
    private TextField fullNameField;

    @FXML
    private TextField phoneNumberField;

    @FXML
    private Button registerButton;

    @Autowired
    private ClientService clientService;

    @Autowired
    public ClientRegistrationController(ClientService clientService) {
        this.clientService = clientService;
    }

    public void initialize() {
        registerButton.setOnAction(event -> registerClient(emailField.getText(), fullNameField.getText(), phoneNumberField.getText()));
    }

    private void registerClient(String email, String fullName, String phoneNumber) {
        // Отправка запроса на сервер для регистрации клиента
        try {
            URL url = new URL("http://localhost:8012/clients/add");  // Путь для добавления клиента
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);

            // Подготовка данных для отправки в запросе
            String jsonInputString = "{ \"email\": \"" + email + "\", \"fullName\": \"" + fullName + "\", \"phoneNumber\": \"" + phoneNumber + "\"}";

            System.out.println("JSON to send: " + jsonInputString);

            // Отправка данных на сервер
            try (OutputStream os = connection.getOutputStream()) {
                byte[] input = jsonInputString.getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            // Получение ответа от сервера
            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                showAlert("Registration Successful", "You have been successfully registered.");
            } else {
                showAlert("Registration Failed", "Something went wrong. Please try again.");
            }

        } catch (Exception e) {
            showAlert("Error", "Unable to connect to the server.");
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
