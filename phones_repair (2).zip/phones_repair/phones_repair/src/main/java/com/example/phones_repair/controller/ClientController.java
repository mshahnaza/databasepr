package com.example.phones_repair.controller;


import com.example.phones_repair.dto.user.ClientRegisterRequest;
import com.example.phones_repair.service.ClientService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/clients")
@AllArgsConstructor
public class ClientController {
    @Autowired
    private ClientService clientService;

    @PostMapping("/add")
    public void addClient(ClientRegisterRequest registerRequest){
        clientService.registerClient(registerRequest);
    }

}