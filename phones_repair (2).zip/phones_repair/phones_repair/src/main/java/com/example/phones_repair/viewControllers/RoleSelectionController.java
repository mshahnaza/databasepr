package com.example.phones_repair.viewControllers;

import javafx.fxml.FXML;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import net.rgielen.fxweaver.core.FxWeaver;
import net.rgielen.fxweaver.core.FxmlView;
import org.springframework.stereotype.Component;

@Component
@FxmlView("/view/RoleSelectionView.fxml")
public class RoleSelectionController {

    private final FxWeaver fxWeaver;

    @FXML
    private Button clientButton;

    @FXML
    private Button workerButton;

    public RoleSelectionController(FxWeaver fxWeaver) {
        this.fxWeaver = fxWeaver;
    }

    @FXML
    public void initialize() {
        clientButton.setOnAction(e -> openClientRegistrationWindow());
        //workerButton.setOnAction(e -> openWorkerWindow());
    }

    private void openClientRegistrationWindow() {
        // Загружаем окно клиента из FXML
        Parent clientView = fxWeaver.loadView(ClientRegistrationController.class);
        Stage stage = new Stage();
        stage.setTitle("Client Registration");
        stage.setScene(new Scene(clientView));
        stage.show();
    }

//    private void openWorkerWindow() {
//        fxWeaver.loadView(WorkerWindow.class);
//    }
}
